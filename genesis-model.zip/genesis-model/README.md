# ⛳ Genesis Invitational 2026 — Predictive Model

A data-driven predictive model for the 2026 Genesis Invitational at Riviera Country Club. Built with React and weighted strokes gained analysis across 10 statistical categories.

**Live features:**
- Predicted Top 10 leaderboard with expandable player cards
- Interactive weight sliders — adjust any category and rankings update instantly
- Player deep-dive view with radar chart and full category breakdown
- Riviera course history and Augusta 2025 result chips

---

## 🚀 Deploy to GitHub Pages (Step-by-Step)

This site requires **zero build tools** — it runs entirely from a single `index.html` file using CDN-hosted libraries.

### Step 1 — Create a GitHub account
If you don't have one, sign up at [github.com](https://github.com).

### Step 2 — Create a new repository
1. Click the **+** icon (top right) → **New repository**
2. Name it anything, e.g. `genesis-2026-model`
3. Set it to **Public**
4. Check **"Add a README file"**
5. Click **Create repository**

### Step 3 — Upload the file
1. Inside your new repo, click **Add file** → **Upload files**
2. Drag and drop `index.html` from this folder
3. Scroll down and click **Commit changes**

### Step 4 — Enable GitHub Pages
1. Go to your repo's **Settings** tab
2. In the left sidebar, click **Pages**
3. Under **Branch**, select `main` and folder `/ (root)`
4. Click **Save**

### Step 5 — Visit your live site
After ~60 seconds, your site will be live at:
```
https://YOUR-USERNAME.github.io/genesis-2026-model/
```
GitHub will show the exact URL at the top of the Pages settings page.

---

## 📁 File Structure

```
genesis-model/
└── index.html      ← The entire app (HTML + React + data, all in one file)
```

That's it. No `npm install`, no build step, no config files needed.

---

## 🔧 Updating Player Data

All player data lives inside `index.html` in the `RAW_PLAYERS` array (around line 60). Each player object looks like:

```js
{
  "name": "Scottie Scheffler",
  "score_sg_ott": 100.0,      // SG: Off the Tee (0–100 normalized)
  "score_sg_putt": 70.32,     // SG: Putting
  "score_sg_app": 68.59,      // SG: Approach
  "score_sg_arg": 67.47,      // SG: Around Green
  "score_sg_ttg": 96.47,      // SG: Tee to Green
  "score_masters": 96.63,     // Augusta 2025 finish (null if N/A)
  "score_torrey": null,       // Torrey 2026 finish
  "score_riviera": 100,       // Riviera history score (0–100)
  "score_par4": 95.83,        // Par 4 scoring
  "score_random": 68.43,      // Randomness factor
  "raw_sg_ott": 1.026,        // Raw PGA Tour stat values
  "raw_sg_putt": 0.703,
  "raw_sg_app": 0.424,
  "raw_sg_arg": 0.645,
  "raw_sg_ttg": 2.094,
  "raw_par4": 3.80,
  "riv2024": "N/A",           // Riviera finish by year
  "riv2023": "-8",
  "riv2022": "-12",
  "riv2021": "N/A",
  "masters2025": "T4"
}
```

To add a player, copy an existing entry, update the values, and add it to the array.

---

## ⚖️ Default Category Weights

| Category | Default Weight |
|---|---|
| SG: Off the Tee | 15% |
| SG: Putting | 15% |
| SG: Approach | 12% |
| SG: Tee to Green | 11% |
| Par 4 Scoring | 11% |
| SG: Around Green | 11% |
| Riviera History | 10% |
| Augusta 2025 | 5% |
| Torrey 2026 | 5% |
| Randomness | 5% |

Weights are fully adjustable in the **Weights** tab of the live site.

---

*Built with React 18, Recharts, and PGA Tour official statistics.*
